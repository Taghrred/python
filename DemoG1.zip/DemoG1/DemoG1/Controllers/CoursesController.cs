﻿using DemoG1.Data;
using DemoG1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace DemoG1.Controllers
{
    public class CoursesController : Controller
    {
        public AppDbContext db;
        public CoursesController(AppDbContext _db)
        {
            db = _db;
        }
        public IActionResult Index()
        {

            var coursesList = db.Courses.Include(x => x.Student);
            return View(coursesList);
        }
        [HttpGet]
        public IActionResult Create()
        {
            //  var StuN = db.Students.ToList();
            //  ViewBag.StuN = new SelectList(StuN,"StudentId","StudentName");
            //  ViewBag.StuN = new SelectList(db.Students.ToList(),"StudentName");
            ViewBag.StudInfo = new SelectList(db.Students, "StudentId","StudentName");
            return View();
            
        }

        [HttpPost]
        public IActionResult Create(Course course)
        {      
            if (ModelState.IsValid) { 
            db.Courses.Add(course);
            db.SaveChanges();
            return RedirectToAction("Index");
            }
            return RedirectToAction("course");

        }
    }
}
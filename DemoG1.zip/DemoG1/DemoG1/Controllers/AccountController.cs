﻿using DemoG1.Data;
using DemoG1.Models.ModelView;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoG1.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        #region Settings
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AccountController(UserManager<AppUser> userManager,
            SignInManager<AppUser> signInManager,
            RoleManager<IdentityRole> roleManager

            )
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
        }
        #endregion
        #region Users
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new AppUser
                {
                    Email = model.UserEmail,
                    UserName = model.UserEmail,
                    PhoneNumber = model.PhoneNumber,
                    Gender = model.Gender,
                    Address = model.Address,
                    City = model.City
                };

                var r = await _userManager.CreateAsync(user, model.Password);
                if (r.Succeeded)
                {
                    await _signInManager.SignInAsync(user, false);
                    return RedirectToAction("Index", "Courses");
                }
                foreach (var errors in r.Errors)
                {
                    ModelState.AddModelError(String.Empty, errors.Description);
                }
            }
            return View();
        }

        [HttpGet]
        [AllowAnonymous]

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, false);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Courses");
                }
                ModelState.AddModelError(String.Empty, "wrong user/pass");
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
        #endregion
        #region Roles
        [HttpGet]
        [Authorize(Roles = "Super Admain2")]
        public IActionResult CreateRole()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Super Admain2")]

        public async Task<IActionResult> CreateRole(CreateRoleViewModel model)
        {
            if (ModelState.IsValid)
            {
                IdentityRole identityRole = new IdentityRole
                {
                    Name = model.RoleName
                };
                var result = await _roleManager.CreateAsync(identityRole);
                if (result.Succeeded)
                {
                    return RedirectToAction("ListRoels");
                }
                foreach (var errors in result.Errors)
                {
                    ModelState.AddModelError(String.Empty, errors.Description);
                }

            }
            return View(model);
        }
        [HttpGet]
        [Authorize(Roles = "Super Admain2")]

        public IActionResult ListRoels()
        {
            var roles = _roleManager.Roles;
            return View(roles);
        }
        [HttpGet]
        public async Task<IActionResult> EditRole(string id)
        {
            var role = await _roleManager.FindByIdAsync(id);
            if (role == null)
            {
                return View("NotFound");

            }
            var model = new EditRoleViewModel
            {
                Id = role.Id,
                RoleName = role.Name
            };
            foreach (var user in _userManager.Users)
            {
                if (await _userManager.IsInRoleAsync(user, role.Name))
                {
                    model.Users.Add(user.UserName);
                }
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditRole(EditRoleViewModel m)
        {
            var role = await _roleManager.FindByIdAsync(m.Id);
            if (role == null)
            {
                return View("NotFound");

            }
            else
            {
                role.Name = m.RoleName;
                var r = await _roleManager.UpdateAsync(role);
                {
                    if (r.Succeeded)
                    {
                        return RedirectToAction("ListRoels");
                    }
                    foreach (var errors in r.Errors)
                    {
                        ModelState.AddModelError(String.Empty, errors.Description);
                    }

                }
                return View(m);
            }
        }

        [HttpGet]
        public async Task<IActionResult> EditUserRole(string id)
        {
            ViewBag.roleID = id;
            var role = await _roleManager.FindByIdAsync(id);
            if (role == null)
            {
                return View("NotFound");
            }
            var model = new List<UserRoleViewModel>();
            foreach (var user in _userManager.Users)
            {
                var userRoleViewModel = new UserRoleViewModel
                {
                    UserId = user.Id,
                    UserName = user.UserName
                };
                if (await _userManager.IsInRoleAsync(user, role.Name))
                {
                    userRoleViewModel.isSelection = true;
                }
                else
                {
                    userRoleViewModel.isSelection = false;
                }
                model.Add(userRoleViewModel);
            }
            return View(model);

        }

        [HttpPost]
        public async Task<IActionResult> EditUserRole(List<UserRoleViewModel> model, string roleID)
        {
            var role = await _roleManager.FindByIdAsync(roleID);
            if (role==null)
            {
                return View("NotFound");
            }
            for (int i = 0; i < model.Count; i++)
            {
                IdentityResult result = null;
                var user = await _userManager.FindByIdAsync(model[i].UserId);
                if (model[i].isSelection && !(await _userManager.IsInRoleAsync(user, role.Name)))
                {
                    result =  await _userManager.AddToRoleAsync(user, role.Name);
                }
                else if (!model[i].isSelection && await _userManager.IsInRoleAsync(user, role.Name)) 
                {
                    result = await _userManager.RemoveFromRoleAsync(user, role.Name);
                }
                else
                {
                    continue;
                }
                if (result.Succeeded)
                    continue;
            }
            return RedirectToAction("ListRoels");
        }
    
        #endregion
    }
}

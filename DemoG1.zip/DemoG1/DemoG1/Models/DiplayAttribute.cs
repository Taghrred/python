﻿using System;

namespace DemoG1.Models
{
    internal class DiplayAttribute : Attribute
    {
    }
}
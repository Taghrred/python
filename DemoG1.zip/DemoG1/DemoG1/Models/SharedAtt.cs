﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoG1.Models
{
    public class SharedAtt
    {
        public DateTime CreationData { get; set; }
        public int UpdatedDate { get; set; }
        public bool isDeleted { get; set; }
    }
}

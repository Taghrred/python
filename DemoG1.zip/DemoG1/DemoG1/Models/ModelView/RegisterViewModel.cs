﻿using DemoG1.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DemoG1.Models.ModelView
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage ="Please Enter Email Address")]
        [Display(Name ="User Email")]
        public string UserEmail { get; set; }

        [Required(ErrorMessage = "Please Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required(ErrorMessage = "Please Enter Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage ="Miss Match Password and confirmation...")]
        public string ConfirmPassword { get; set; }

        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string City { get; set; }

        public string Gender { get; set; }
    }
}

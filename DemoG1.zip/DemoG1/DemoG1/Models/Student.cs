﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DemoG1.Models
{
    public class Student:SharedAtt
    {
        [Display(Name ="Student Number")]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "Please Enter Student Name")]
        [MinLength(3,ErrorMessage ="Student Name Should Be 3 Char min...")]
        [Display(Name = "Student Name")]
        public String StudentName { get; set; }
        [Required]
        [Range(18,80,ErrorMessage ="Age Between 18-80")]
        public int Age { get; set; }
        public String City { get; set; }
        [Required(ErrorMessage ="Enter Email")]
        [EmailAddress]
        public String Email { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Birth Of Date")]
        public DateTime BOD { get; set; }
        [Required(ErrorMessage ="Please Select Your Major")]
        public Major Major { get; set; }
        public Gender Gender { get; set; }
    }
    public enum Major
    {
        IT,
        Finance,
        Graphic,
        HR
    }
    public enum Gender { 
        Male , Female
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace DemoG1.Models
{
    public class Course : SharedAtt
    {
        [Display(Name ="Course Number")]
        public int CourseId { get; set; }
        [Display(Name = "Course Name")]
        [Required(ErrorMessage ="Enter Course Name")]
        public String CourseName { get; set; }
        [Required(ErrorMessage = "Enter Course Period")]
        public DateTime Period { get; set; }
        [Required]
        [DataType(DataType.Currency)]
        [Range(100,2500,ErrorMessage ="Between 1-- -2500 JD")]
        public decimal Cost { get; set; }
        public int StudentId { get; set; } 
        public Student Student { get; set; }
    }
}
